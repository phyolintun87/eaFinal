/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mum.ea.model;

/**
 *
 * @author umurinan
 */
public class MemberModel {

    private Long id;
    private String firstname;
    private String lastname;
    private String username;
    private String password;
    private String mail;
    private Long idMemberType;
    
    private MemberType memberType;

    public MemberType getMemberType() {
        return memberType;
    }

    public void setMemberTyp(MemberType memberType) {
        this.memberType= memberType;
    }

    public Long getIdMemberType() {
        return idMemberType;
    }

    public void setIdMemberType(Long idMemberType) {
        this.idMemberType = idMemberType;
    }
    
    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    
    
}
